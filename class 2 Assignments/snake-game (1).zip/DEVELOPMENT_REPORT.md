# My Snake Game: Development & Prompt Engineering Report

Hello! This is my project report. I wrote it to explain how I developed my **Retro Cyberpunk Snake Game** using AI prompts. As a student, I have written this in simple, everyday English to describe what I requested, how the code evolved, what worked, what didn't work, and the challenges we overcame together!

---

## 1. About the Snake Game We Built
We created a fully complete, feature-rich **Classic Snake Game** with a modern cyberpunk style. Here's what makes it so cool:
* **The Gameplay:** Smooth grid-based snake movement inside a custom styled arena.
* **Particle Effect Engine:** When the snake eats food, colorful neon particles burst on the screen using standard HTML5 Canvas physics animations!
* **Synthesized Sound Effects:** The game produces real-time synth sounds for eating food, eating golden apples, clicking, and making a game over sound. Since we didn't want heavy audio files to load, the code dynamically generates sound waves directly in the player's web browser using the **Web Audio API**!
* **Skins & Shop System:** Players can earn game coin tokens during rounds, go to a custom skins shop, and buy cool customized designs (like special colors and patterns) to skin their snake.
* **Database & Leaderboards:** It syncs high-scores and unlocked skins to Google Firestore. 
* **Bulletproof Offline Cache:** If the database is disconnected or internet is cut, everything saves smoothly in the browser's local state, allowing offline gameplay without losing coins or high-scores!

---

## 2. Prompt Iterations (How My Prompts Evolved)

At the beginning of the project, my prompts were too short and simple. I learned that to build complex features like particle systems and audio synths, I had to write highly descriptive prompts with logical boundaries.

### Phase 1: Simple Concept (Prompting the Basics)
* **What I asked the AI:** 
  > *"Write a simple snake game in React with a neon color theme."*
* **What worked:** The AI gave me a basic game with green squares moving around. It had simple state controls.
* **What did not work:** The graphics looked like blocks, there was no sound, no skins shop, and if the user pressed keys too fast, the snake would crash into itself (the double-key-press bug).

### Phase 2: Adding Interactive Audio & Visual Polish (Adding Details)
* **What I asked the AI:** 
  > *"Make the snake game feel alive. Add real-time sound effects when the snake eats food or fails, and make a colorful particle explosion when food is swallowed. Do not use external MP3 file links; generate sounds using simple sound frequencies in the browser."*
* **What worked:** The AI implemented Web Audio API oscillators to generate sine and sawtooth sound waves in real-time! It also added active state particle variables that calculate velocities and decay on every paint cycle.
* **What did not work:** The sound would sometimes lock up if the browser blocked the audio context, and the high-score boards crashed if the database was not connected.

### Phase 3: Robust Error Defenses & Firebase Protection (Polishing for Release)
* **What I asked the AI:** 
  > *"If the player is offline or Firebase is down, save all scores and skins to local state memory. Wrap Google Auth in a safety function to catch popups closed early by the user, and notify them on a clean alert box without crashing."*
* **What worked:** Beautiful! The AI implemented custom `try-catch` structures. We added an interactive **Game Notification Center** that pops up elegantly whenever network delays are detected, allowing guests to keep buying skins and setting new scores offline!

---

## 3. What Worked Well

* **Procedural Sound Design:** Generating sound effects with code waveforms means the game is incredibly lightweight. It loads in milliseconds since it does not have to download audio clips.
* **Direct Canvas Rendering:** Drawing the snake, the glowing grid lines, golden food timers, and neon particles on a single 2D Canvas context kept the game running at a lightning-fast 60 frames-per-second.
* **State Isolation:** Separating the game arena code from user authentication and database models meant we could debug the game logic completely separate from the backend features.

---

## 4. What Did Not Work (Lessons Learned)

* **Generic Vague Requests:** Prompts like *"Make the game look better"* did not work. The AI would change random layouts and mess up the canvas proportions. I had to specify exactly: *"Apply deep charcoal gray offsets, glowing neon green borders, and italic typography displays."*
* **Keyboard Overloading:** Initially, if a player tapped the *DOWN* arrow and immediately the *RIGHT* arrow before the next game tick, the direction would change instantly twice and the snake would crash into itself. We had to fix this by using `nextDirectionRef` to safely buffer turns.
* **Iframe Popup Authentication:** Some browsers blocked the Firebase Google Login popups, causing runtime failures. We resolved this by building an automatic local-guest mode.

---

## 5. How My Prompts Improved Over Time

| Early Prompts | Modern Strategic Prompts | What Changed & Why |
|---|---|---|
| *"Add sounds to the game."* | *"Create a Web Audio API synth sound synthesizer handling 'eat' frequency sweeps (sine wave 220Hz to 880Hz) and 'gameover' sweeps (sawtooth 180Hz to 50Hz)."* | Specified exactly how to generate procedural sounds without relying on broken MP3 download links. |
| *"Fix database saving errors."* | *"If Firestore returns a client-is-offline warning, update game connection state to DISCONNECTED, store coins safely into localStorage, and update the UI with a 'Playing Offline Mode' alert."* | Guaranteed the app continues to operate flawlessly even when offline or disconnected. |
| *"Make a scoreboard."* | *"Create a leaderboards list sorting the top 10 players, displaying their names, unlocked snake skin, and date. Render offline values if the cloud is unreachable."* | Designed a highly structured, sturdy component with full error isolation. |

---

## 6. Challenges Faced & How We Solved Them

### Challenge A: The Safe Speed Buffer (Preventing Self-Collisions)
* **The Problem:** The snake would crash and trigger an unfair Game Over if players turned extremely quickly, because the game registered a 180-degree turn inside a single speed frame.
* **The Solution:** I prompted the AI to save the immediate input direction in a temporary buffer variable (`nextDirectionRef`). The game loop now only shifts the snake to the next direction when a new physical step tick is resolved, preventing accidental self-collision.

### Challenge B: Popups & Sandbox Security Blocks
* **The Problem:** Hosting the game inside an interactive student workspace or an iframe sandbox often blocks Google Sign-In windows or causes players to cancel logins.
* **The Solution:** We wrapped the authentication function in a custom handler. If the popup fails or is closed, the system shows a clean, player-friendly cyberpunk alert bar, dismisses the warning safely, and transitions the game state to offline local guest memory.

---

## 7. Conclusion

This project was a fantastic learning experience! I learned that:
1. **Details Matter:** The quality of the AI's code depends entirely on how clear and specific my instructions are.
2. **Handle Every Error Safely:** A great game doesn't just work under perfect conditions; it must remain completely playable and friendly when things go wrong (like internet dropouts or closed popups).
3. **Write Simple UI Reports:** Translating technical errors into human-readable warnings (like our Game Notification Center) makes the interface feel high quality and professional.

I am super excited to share this game with my mentor! By learning how to steer AI tools with logical prompts, I successfully created a polished cyberpunk Snake game from scratch!
