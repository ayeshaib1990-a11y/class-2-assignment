# Security Specification - Snake Game

This document outlines the security invariants, a series of malicious payloads (the "Dirty Dozen") designed to verify the security of our Firestore database rules, and the design constraints.

## 1. Data Invariants

1.  **Strict Profile Identity**: A user profile document `/users/{userId}` can only be created or written by the user themselves whose authenticated UID exactly matches `{userId}`.
2.  **No Leaderboard Modifying**: A leaderboard entry `/leaderboard/{entryId}` can only be created (written once) and never updated or deleted.
3.  **Immutable Core Fields**: Once created, historical score records, `userId`, and `createdAt` are immutable.
4.  **Coin Accumulation Guard**: Coins can only be accrued incrementally. Under a strict client model, write operations to the coin count must validate types, formatting, and acceptable ranges.
5.  **Strict ID Formats**: User and entry IDs must conform to alphanumeric formatting (`^[a-zA-Z0-9_\-]+$`) with a maximum length of 128 characters to prevent injection attacks or ID poisoning.
6.  **Temporal Authenticity**: All creations and updates must bind their dynamic timestamps (`createdAt`, `updatedAt`) to the server's time (`request.time`).
7.  **Skins Shop Whitelist**: Active skins must be from the defined whitelist: `['classic', 'neon_blue', 'sunset_orange', 'rainbow', 'stealth_gray', 'golden_dragon', 'ghost']`.

---

## 2. The "Dirty Dozen" Malicious Payloads

The following test cases describe malicious operations trying to bypass security.

### Test 1: Identity Spoofing (Create profile for another user)
*   **Path**: `/users/legit_user`
*   **Payload**: `{ "userId": "legit_user", "displayName": "Attacker", "coins": 0, "highScore": 0, "unlockedSkins": ["classic"], "activeSkin": "classic", "createdAt": "SERVER_TIMESTAMP", "updatedAt": "SERVER_TIMESTAMP" }`
*   **Actor**: Authenticated with UID `attacker_uid`
*   **Expected Outcome**: `PERMISSION_DENIED`

### Test 2: Shadow Fields Injection (Add a secret field)
*   **Path**: `/users/legit_user`
*   **Payload**: `{ "userId": "legit_user", "displayName": "Legit", "coins": 0, "highScore": 0, "unlockedSkins": ["classic"], "activeSkin": "classic", "createdAt": "SERVER_TIMESTAMP", "updatedAt": "SERVER_TIMESTAMP", "isAdmin": true }`
*   **Actor**: Authenticated with UID `legit_user`
*   **Expected Outcome**: `PERMISSION_DENIED` (due to exact key length and strict key checks)

### Test 3: State Shortcutting (Give self unlimited coins)
*   **Path**: `/users/legit_user`
*   **Payload (Update)**: Modifying `coins` from `100` to `9999999`
*   **Actor**: Authenticated with UID `legit_user`
*   **Expected Outcome**: `PERMISSION_DENIED` unless checked or restricted properly. We will enforce that updates must match the validation schema and types.

### Test 4: Resource Poisoning (Display name size overload)
*   **Path**: `/users/legit_user`
*   **Payload**: `{ "userId": "legit_user", "displayName": "A".repeat(5000), "coins": 0, "highScore": 0, "unlockedSkins": ["classic"], "activeSkin": "classic", "createdAt": "SERVER_TIMESTAMP", "updatedAt": "SERVER_TIMESTAMP" }`
*   **Actor**: Authenticated with UID `legit_user`
*   **Expected Outcome**: `PERMISSION_DENIED` (exceeds size limit of 30 characters)

### Test 5: ID Poisoning (Injecting huge characters or escape sequences as IDs)
*   **Path**: `/users/invalid_id$$%^%&*`
*   **Payload**: `{ "userId": "invalid_id$$%^%&*", "displayName": "Buggy", "coins": 0, "highScore": 0, "unlockedSkins": ["classic"], "activeSkin": "classic", "createdAt": "SERVER_TIMESTAMP", "updatedAt": "SERVER_TIMESTAMP" }`
*   **Actor**: Authenticated with UID `invalid_id$$%^%&*`
*   **Expected Outcome**: `PERMISSION_DENIED`

### Test 6: Bypassing Skins Whitelist
*   **Path**: `/users/legit_user`
*   **Payload**: `{ "userId": "legit_user", "displayName": "Legit", "coins": 0, "highScore": 0, "unlockedSkins": ["classic", "god_mode_skin"], "activeSkin": "god_mode_skin", "createdAt": "SERVER_TIMESTAMP", "updatedAt": "SERVER_TIMESTAMP" }`
*   **Actor**: Authenticated with UID `legit_user`
*   **Expected Outcome**: `PERMISSION_DENIED` (skin identifier does not exist in the valid skin pool)

### Test 7: Score Tampering (Record score of 99999 on other user's behalf)
*   **Path**: `/leaderboard/attacker_score_id`
*   **Payload**: `{ "userId": "victim_uid", "displayName": "Victim", "score": 99999, "skinUsed": "classic", "createdAt": "SERVER_TIMESTAMP" }`
*   **Actor**: Authenticated with UID `attacker_uid`
*   **Expected Outcome**: `PERMISSION_DENIED` (auth userId must match payload userId)

### Test 8: Leaderboard High Score Modification (Attacker tries to overwrite high score records)
*   **Path**: `/leaderboard/existing_high_score_id`
*   **Action**: `UPDATE` (tampering with score from 150 to 500)
*   **Actor**: Authenticated with UID `legit_user`
*   **Expected Outcome**: `PERMISSION_DENIED` (leaderboard is write-once, no updates or deletes are ever allowed)

### Test 9: Anonymous Score Submission Bypass (Trying to submit score as unauthenticated)
*   **Path**: `/leaderboard/anon_score_id`
*   **Payload**: `{ "userId": "unauth_user", "displayName": "Anonymous Cheater", "score": 1000, "skinUsed": "classic", "createdAt": "SERVER_TIMESTAMP" }`
*   **Actor**: Unauthenticated
*   **Expected Outcome**: `PERMISSION_DENIED` (Authentication required)

### Test 10: Negative High Score Submission
*   **Path**: `/leaderboard/negative_score`
*   **Payload**: `{ "userId": "legit_uid", "displayName": "Glitcher", "score": -500, "skinUsed": "classic", "createdAt": "SERVER_TIMESTAMP" }`
*   **Actor**: Authenticated with UID `legit_uid`
*   **Expected Outcome**: `PERMISSION_DENIED` (score must be >= 0)

### Test 11: Temporal Bypassing (Placing a future/past timestamp)
*   **Path**: `/leaderboard/score_id`
*   **Payload**: `{ "userId": "legit_uid", "displayName": "TimeTraveler", "score": 100, "skinUsed": "classic", "createdAt": "2030-01-01T00:00:00Z" }`
*   **Actor**: Authenticated with UID `legit_uid`
*   **Expected Outcome**: `PERMISSION_DENIED` (createdAt must match request.time)

### Test 12: Leaderboard Record Deletion (Wiping out high scores)
*   **Path**: `/leaderboard/highest_score_id`
*   **Action**: `DELETE`
*   **Actor**: Authenticated with UID `legit_uid`
*   **Expected Outcome**: `PERMISSION_DENIED` (deletions are blocked)

---

## 3. Test Verification Rules Blueprint

These rules are translated into `firestore.rules` below.
