import { useEffect, useState } from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType, UserProfile, loginWithGoogle, logout, SKINS_SHOP } from './firebase';
import GameCanvas from './components/GameCanvas';
import SkinsShop from './components/SkinsShop';
import Leaderboard from './components/Leaderboard';
import { Gamepad2, Trophy, ShoppingBag, User, LogIn, LogOut, Coins, Edit, Save, Zap, AlertTriangle, ShieldCheck } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  
  // Local/Anonymous states for offline mode
  const [anonCoins, setAnonCoins] = useState<number>(() => {
    return Number(localStorage.getItem('snake_anon_coins')) || 100; // start with 100 bonus coins on first play!
  });
  const [anonUnlockedSkins, setAnonUnlockedSkins] = useState<string[]>(() => {
    const list = localStorage.getItem('snake_anon_unlocked_skins');
    return list ? JSON.parse(list) : ['classic'];
  });
  const [anonActiveSkin, setAnonActiveSkin] = useState<string>(() => {
    return localStorage.getItem('snake_anon_active_skin') || 'classic';
  });
  const [anonHighScore, setAnonHighScore] = useState<number>(() => {
    return Number(localStorage.getItem('snake_anon_highscore')) || 0;
  });

  // UI state managers
  const [activeTab, setActiveTab] = useState<'play' | 'shop' | 'leaderboard'>('play');
  const [editingName, setEditingName] = useState(false);
  const [tempName, setTempName] = useState('');
  const [authLoading, setAuthLoading] = useState(true);
  const [dbStatus, setDbStatus] = useState<'OK' | 'DISCONNECTED'>('OK');
  const [showSyncNotification, setShowSyncNotification] = useState(false);
  const [notifyError, setNotifyError] = useState<{ title: string; message: string; type: 'info' | 'warning' | 'error' } | null>(null);

  // Initialize Auth state listeners
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setAuthLoading(true);
      if (firebaseUser) {
        setUser(firebaseUser);
        await syncUserProfile(firebaseUser);
      } else {
        setUser(null);
        setUserProfile(null);
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Safe wrapper for trigger Google Sign In
  const handleGoogleSignIn = async () => {
    setNotifyError(null);
    try {
      await loginWithGoogle();
    } catch (error: any) {
      const errMsg = error?.message || String(error);
      if (error?.code === 'auth/popup-closed-by-user' || errMsg.includes('popup-closed-by-user')) {
        setNotifyError({
          title: 'Sign-In Window Closed',
          message: 'The Google Login popup was closed before authenticate sequence could resolve. You can continue playing in secure offline local state.',
          type: 'info'
        });
      } else if (error?.code === 'auth/network-request-failed' || errMsg.includes('offline') || errMsg.includes('network')) {
        setNotifyError({
          title: 'Authentication Offline',
          message: 'Failed to establish connection with Google identity nodes. Please check your internet connection.',
          type: 'error'
        });
      } else {
        setNotifyError({
          title: 'Authentication Protocol Warning',
          message: errMsg || 'An unforeseen authentication event occurred. Please retry.',
          type: 'warning'
        });
      }
    }
  };

  // Sync profile loader and creator
  const syncUserProfile = async (firebaseUser: FirebaseUser) => {
    const userRef = doc(db, 'users', firebaseUser.uid);
    try {
      const docSnap = await getDoc(userRef);

      if (docSnap.exists()) {
        const profile = docSnap.data() as UserProfile;
        setUserProfile(profile);
        setTempName(profile.displayName);
        
        // If there is existing anonymous progress, notify of a potential sync opportunity
        if (anonHighScore > profile.highScore || anonCoins > 100) {
          setShowSyncNotification(true);
        }
      } else {
        // Create initial default user profile
        const defaultName = firebaseUser.displayName || `CyberPilot_${Math.floor(1000 + Math.random() * 9000)}`;
        const newProfile: UserProfile = {
          userId: firebaseUser.uid,
          displayName: defaultName,
          photoURL: firebaseUser.photoURL || undefined,
          coins: anonCoins > 100 ? anonCoins : 100, // keep local surplus coins if they acquired them
          highScore: anonHighScore > 0 ? anonHighScore : 0, // integrate local offline high scores
          unlockedSkins: anonUnlockedSkins.length > 1 ? anonUnlockedSkins : ['classic'],
          activeSkin: anonActiveSkin,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };

        try {
          await setDoc(userRef, newProfile);
          setUserProfile(newProfile);
          setTempName(defaultName);
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, `users/${firebaseUser.uid}`);
        }
      }
      setDbStatus('OK');
    } catch (err: any) {
      console.warn('Notice: Error fetching user profile while offline:', err);
      setDbStatus('DISCONNECTED');
      
      const errMsg = err?.message || String(err);
      if (errMsg.includes('offline') || err?.code === 'unavailable' || errMsg.includes('client is offline')) {
        setNotifyError({
          title: 'Playing Offline Mode',
          message: 'Connection offline. achievements and currency tokens are safely preserved in local memory cache.',
          type: 'info'
        });
      } else {
        setNotifyError({
          title: 'Database Synchronization Delayed',
          message: errMsg || 'An issue occurred syncing your account profile.',
          type: 'warning'
        });
      }
    }
  };

  // Safe manual merge of anonymous locally stored score & currency into Google Cloud Profile
  const mergeOfflineCoinsAndScores = async () => {
    if (!user || !userProfile) return;
    const userRef = doc(db, 'users', user.uid);
    
    // Merged settings
    const mergedCoins = userProfile.coins + (anonCoins - 100 > 0 ? anonCoins - 100 : 0);
    const mergedHighScore = Math.max(userProfile.highScore, anonHighScore);
    
    // Merge skins list
    const combinedSkins = Array.from(new Set([...userProfile.unlockedSkins, ...anonUnlockedSkins]));

    const updates = {
      coins: mergedCoins,
      highScore: mergedHighScore,
      unlockedSkins: combinedSkins,
      updatedAt: serverTimestamp()
    };

    try {
      await updateDoc(userRef, updates);
      setUserProfile(prev => prev ? { ...prev, ...updates } : null);
      
      // Wipe anonymous progression so it doesn't prompt again
      setAnonCoins(100);
      setAnonHighScore(mergedHighScore);
      setAnonUnlockedSkins(['classic']);
      localStorage.setItem('snake_anon_coins', '100');
      localStorage.setItem('snake_anon_highscore', String(mergedHighScore));
      localStorage.setItem('snake_anon_unlocked_skins', JSON.stringify(['classic']));
      
      setShowSyncNotification(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  // Save Display name changes in database
  const saveDisplayName = async () => {
    const trimmedName = tempName.trim();
    if (!trimmedName || trimmedName.length < 1 || trimmedName.length > 30) return;
    
    if (user) {
      const userRef = doc(db, 'users', user.uid);
      try {
        await updateDoc(userRef, {
          displayName: trimmedName,
          updatedAt: serverTimestamp()
        });
        setUserProfile(prev => prev ? { ...prev, displayName: trimmedName } : null);
        setEditingName(false);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      }
    } else {
      localStorage.setItem('snake_anon_name', trimmedName);
      setEditingName(false);
    }
  };

  // Submit high scores and secure points upon system terminated game over
  const onGameEnd = async (finalScore: number, finalCoinsEarned: number) => {
    if (user && userProfile) {
      const isNewHighScore = finalScore > userProfile.highScore;
      const updatedHighScore = isNewHighScore ? finalScore : userProfile.highScore;
      const updatedCoins = userProfile.coins + finalCoinsEarned;
      
      const userRef = doc(db, 'users', user.uid);
      const updates = {
        coins: updatedCoins,
        highScore: updatedHighScore,
        updatedAt: serverTimestamp()
      };

      try {
        // 1. Update Profile stats in Cloud
        await updateDoc(userRef, updates);
        setUserProfile(prev => prev ? { ...prev, ...updates } : null);

        // 2. Write to leaderboards if they set a new high score
        if (isNewHighScore) {
          await addDoc(collection(db, 'leaderboard'), {
            userId: user.uid,
            displayName: userProfile.displayName,
            score: finalScore,
            skinUsed: userProfile.activeSkin,
            createdAt: serverTimestamp()
          });
        }
      } catch (err) {
        try {
          handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
        } catch (e) {
          // Handled
        }
      }
    } else {
      // Offline local storage progression fallback
      const totalCoins = anonCoins + finalCoinsEarned;
      setAnonCoins(totalCoins);
      localStorage.setItem('snake_anon_coins', String(totalCoins));

      if (finalScore > anonHighScore) {
        setAnonHighScore(finalScore);
        localStorage.setItem('snake_anon_highscore', String(finalScore));
      }
    }
  };

  // Equiping design skins
  const onSelectSkin = async (skinId: string) => {
    if (user && userProfile) {
      const userRef = doc(db, 'users', user.uid);
      try {
        await updateDoc(userRef, {
          activeSkin: skinId,
          updatedAt: serverTimestamp()
        });
        setUserProfile(prev => prev ? { ...prev, activeSkin: skinId } : null);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      }
    } else {
      setAnonActiveSkin(skinId);
      localStorage.setItem('snake_anon_active_skin', skinId);
    }
  };

  // Purchasing layout skin armor
  const onBuySkin = async (skinId: string, price: number) => {
    if (user && userProfile) {
      const userRef = doc(db, 'users', user.uid);
      const updatedCoins = userProfile.coins - price;
      const updatedSkins = [...userProfile.unlockedSkins, skinId];
      
      try {
        await updateDoc(userRef, {
          coins: updatedCoins,
          unlockedSkins: updatedSkins,
          activeSkin: skinId,
          updatedAt: serverTimestamp()
        });
        setUserProfile(prev => prev ? {
          ...prev,
          coins: updatedCoins,
          unlockedSkins: updatedSkins,
          activeSkin: skinId
        } : null);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      }
    } else {
      const updatedCoins = anonCoins - price;
      const updatedSkins = [...anonUnlockedSkins, skinId];
      
      setAnonCoins(updatedCoins);
      setAnonUnlockedSkins(updatedSkins);
      setAnonActiveSkin(skinId);
      
      localStorage.setItem('snake_anon_coins', String(updatedCoins));
      localStorage.setItem('snake_anon_unlocked_skins', JSON.stringify(updatedSkins));
      localStorage.setItem('snake_anon_active_skin', skinId);
    }
  };

  const activeSkin = userProfile ? userProfile.activeSkin : anonActiveSkin;
  const currentCoins = userProfile ? userProfile.coins : anonCoins;
  const currentHighScore = userProfile ? userProfile.highScore : anonHighScore;
  const currentDisplayName = userProfile ? userProfile.displayName : (localStorage.getItem('snake_anon_name') || 'Anonymous Pilot');

  return (
    <div className="min-h-screen bg-dark-bg text-white flex flex-col font-sans antialiased selection:bg-accent/30 selection:text-accent">
      
      {/* Subtle Background Mesh Grid in tone with the design spec */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#111_1px,transparent_1px),linear-gradient(to_bottom,#111_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none z-0"></div>

      {/* Header Section with Bold Typographic Impact */}
      <header className="sticky top-0 z-40 bg-dark-bg/90 backdrop-blur-xl border-b-2 border-accent px-4 md:px-8 py-6 flex flex-col sm:flex-row gap-4 items-center justify-between z-10 max-w-7xl mx-auto w-full">
        <div className="flex items-baseline gap-3">
          <h1 className="text-5xl sm:text-7xl font-black italic uppercase tracking-tighter leading-none">
            NEO<span className="text-accent">SNAKE</span>
          </h1>
          <span className="text-xs uppercase tracking-widest text-zinc-500 font-mono">grid v1.12</span>
        </div>

        {/* Database validation state indicator */}
        <div className="hidden lg:flex items-center gap-2 text-[10px] font-mono border border-zinc-800 bg-card-bg/40 px-3 py-1 text-zinc-400">
          <ShieldCheck className="w-3.5 h-3.5 text-accent" />
          <span className="uppercase tracking-wider">SECTOR AUTO-SAVED PROMPT ACTIVE</span>
        </div>

        {/* Dynamic Player Status Board + Google LogIn Auth Controls */}
        <div className="flex items-center gap-6">
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-widest text-accent font-bold">Current Player</p>
            <p className="text-xl sm:text-2xl font-mono leading-none tracking-tight font-black uppercase text-zinc-100 truncate max-w-[170px]">
              {currentDisplayName}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {authLoading ? (
              <div className="w-10 h-10 bg-zinc-900 animate-pulse border border-zinc-800"></div>
            ) : user ? (
              <div className="flex items-center gap-2.5">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt="avatar"
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 border-2 border-accent object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 border-2 border-zinc-700 bg-zinc-850 flex items-center justify-center">
                    <User className="w-4 h-4 text-zinc-400" />
                  </div>
                )}
                <button
                  onClick={logout}
                  className="p-2.5 bg-card-bg border border-zinc-800 hover:border-red-500/50 text-zinc-400 hover:text-red-400 transition cursor-pointer"
                  title="Disconnect Node"
                >
                  <LogOut className="w-4.5 h-4.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleGoogleSignIn}
                className="flex items-center gap-2 px-4 py-2.5 bg-accent hover:bg-accent-dark text-black transition font-bold uppercase text-[11px] tracking-widest border border-accent cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>SIGN IN</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Dynamic Game Notification Center (for offline status alerts, closed popups etc) */}
      {notifyError && (
        <div className="max-w-7xl mx-auto px-4 md:px-8 mt-4 w-full z-20 relative">
          <div className="bg-card-bg border-l-4 border-accent border border-zinc-805 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex gap-3">
              <div className="p-2 bg-zinc-950 border border-zinc-900 text-accent h-fit">
                <AlertTriangle className="w-4.5 h-4.5 text-accent" />
              </div>
              <div>
                <h4 className="text-xs font-black uppercase tracking-widest text-[#CCFF00] font-mono italic">
                  {notifyError.title}
                </h4>
                <p className="text-[10px] font-mono text-zinc-300 uppercase mt-0.5 leading-relaxed">
                  {notifyError.message}
                </p>
              </div>
            </div>
            <button
              onClick={() => setNotifyError(null)}
              className="px-4 py-1.5 bg-white text-black text-[10px] font-black uppercase tracking-wider hover:bg-accent transition cursor-pointer"
            >
              DISMISS
            </button>
          </div>
        </div>
      )}

      {/* Sync merge notifier if progression discrepant */}
      {showSyncNotification && user && (
        <div className="max-w-4xl mx-auto px-4 mt-4 w-full">
          <div className="bg-amber-950/20 border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex gap-3">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 h-fit">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-zinc-100">Synchronize offline sparks and score records?</h4>
                <p className="text-xs text-zinc-400 mt-0.5">
                  We detected offline achievements on this browser. Merge them safely into your cloud database node.
                </p>
              </div>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <button
                onClick={() => setShowSyncNotification(false)}
                className="flex-1 sm:flex-none px-3.5 py-1.5 text-xs font-semibold text-zinc-400 hover:text-zinc-200 bg-zinc-900 border border-zinc-800 rounded-lg cursor-pointer"
              >
                Skip
              </button>
              <button
                onClick={mergeOfflineCoinsAndScores}
                className="flex-1 sm:flex-none px-3.5 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-amber-950 rounded-lg cursor-pointer flex items-center justify-center gap-1"
              >
                Sync achievements
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Grid Viewport Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 relative z-10">
        
        {/* Left column: User Card Dashboard Widget */}
        <section className="lg:col-span-4 space-y-6">
          <div className="bg-card-bg border-2 border-zinc-800 p-6 relative overflow-hidden flex flex-col justify-between transition-colors shadow-none">
            {/* Decorative mesh */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#0c0c0c_1px,transparent_1px),linear-gradient(to_bottom,#0c0c0c_1px,transparent_1px)] bg-[size:12px_12px] pointer-events-none opacity-40"></div>
            
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] text-[#888] uppercase tracking-widest font-mono font-bold">PILOT PROFILE</span>
                <span className={`text-[10px] uppercase font-mono px-3 py-0.5 border ${
                  user ? 'text-accent bg-accent/10 border-accent/30' : 'text-zinc-500 bg-zinc-900/40 border-zinc-800/40'
                }`}>
                  {user ? 'Cloud Node' : 'Offline Mode'}
                </span>
              </div>

              {/* Display name and status */}
              <div className="flex items-center gap-4 mb-6">
                <div className="relative">
                  <div className={`w-14 h-14 bg-zinc-900 border-2 flex items-center justify-center overflow-hidden ${
                    user ? 'border-accent' : 'border-zinc-800'
                  }`}>
                    {user && user.photoURL ? (
                      <img src={user.photoURL} alt="profile" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    ) : (
                      <User className="w-6 h-6 text-zinc-500" />
                    )}
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 border border-black flex items-center justify-center bg-accent text-black text-[9px] font-bold" title="Skin Equipped">
                    S
                  </div>
                </div>

                <div className="min-w-0 flex-1">
                  {editingName ? (
                    <div className="flex items-center gap-1.5">
                      <input
                        type="text"
                        value={tempName}
                        onChange={(e) => setTempName(e.target.value)}
                        maxLength={30}
                        className="bg-zinc-900 text-sm font-semibold px-2.5 py-1.5 border-2 border-accent text-white max-w-[130px] outline-none font-mono"
                        placeholder="Choose code"
                      />
                      <button
                        onClick={saveDisplayName}
                        className="p-2 bg-accent hover:bg-accent-dark text-black cursor-pointer"
                        title="Save name"
                      >
                        <Save className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-extrabold text-white text-lg tracking-tight uppercase hover:text-accent transition truncate max-w-[150px]">
                        {currentDisplayName}
                      </h3>
                      <button
                        onClick={() => {
                          setEditingName(true);
                          setTempName(currentDisplayName);
                        }}
                        className="p-1 text-zinc-500 hover:text-accent transition cursor-pointer"
                        title="Edit name"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                  <p className="text-[10px] text-[#888] font-mono mt-0.5 uppercase tracking-wide">
                    SKIN ACTIVE: {SKINS_SHOP.find(s => s.id === activeSkin)?.name}
                  </p>
                </div>
              </div>

              {/* Statistics Counters in high-contrast block */}
              <div className="grid grid-cols-2 gap-3.5 p-4 bg-zinc-950 border border-zinc-800 rounded-none mb-4">
                <div>
                  <span className="text-[9px] uppercase font-bold tracking-widest text-zinc-400">Balance</span>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className="text-2xl font-black text-accent font-mono">{currentCoins}</span>
                    <span className="text-xs font-mono text-accent">CR</span>
                  </div>
                </div>

                <div>
                  <span className="text-[9px] uppercase font-bold tracking-widest text-zinc-400 font-sans">High Score</span>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className="text-2xl font-black text-white font-mono">{currentHighScore}</span>
                    <span className="text-xs font-mono text-zinc-500">PTS</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Cloud Storage warning */}
            {!user && (
              <div className="p-4 bg-zinc-950 border border-zinc-900 border-l-2 border-amber-500 mt-2">
                <p className="text-[11px] text-zinc-400 font-medium leading-relaxed font-mono">
                  ANONYMOUS MODE: Achievements locked in cache. Connect database login to rank globally on the leaderboard.
                </p>
              </div>
            )}
          </div>

          {/* Sidebar Navigation Options using flat brutalist colors */}
          <nav className="flex flex-col gap-3">
            <button
              onClick={() => setActiveTab('play')}
              className={`w-full p-4 font-black uppercase text-xs tracking-widest flex items-center justify-between border-2 cursor-pointer transition-all duration-150 ${
                activeTab === 'play'
                  ? 'bg-accent border-accent text-black italic shadow-[4px_4px_0px_0px_#FFFFFF]'
                  : 'bg-card-bg border-zinc-800 text-zinc-400 hover:text-white hover:border-[#CCFF00]'
              }`}
            >
              <div className="flex items-center gap-3">
                <Gamepad2 className="w-5 h-5" />
                <span>START RUN</span>
              </div>
              <span className="text-[10px] font-mono opacity-80">RUN</span>
            </button>

            <button
              onClick={() => setActiveTab('shop')}
              className={`w-full p-4 font-black uppercase text-xs tracking-widest flex items-center justify-between border-2 cursor-pointer transition-all duration-150 ${
                activeTab === 'shop'
                  ? 'bg-accent border-accent text-black italic shadow-[4px_4px_0px_0px_#FFFFFF]'
                  : 'bg-card-bg border-zinc-800 text-zinc-400 hover:text-white hover:border-[#CCFF00]'
              }`}
            >
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-5 h-5" />
                <span>SKIN VAULT</span>
              </div>
              <span className="text-[10px] font-mono opacity-80">VAULT</span>
            </button>

            <button
              onClick={() => setActiveTab('leaderboard')}
              className={`w-full p-4 font-black uppercase text-xs tracking-widest flex items-center justify-between border-2 cursor-pointer transition-all duration-150 ${
                activeTab === 'leaderboard'
                  ? 'bg-accent border-accent text-black italic shadow-[4px_4px_0px_0px_#FFFFFF]'
                  : 'bg-card-bg border-zinc-800 text-zinc-400 hover:text-white hover:border-[#CCFF00]'
              }`}
            >
              <div className="flex items-center gap-3">
                <Trophy className="w-5 h-5" />
                <span>HALL OF VENOM</span>
              </div>
              <span className="text-[10px] font-mono opacity-80">HALL</span>
            </button>
          </nav>
        </section>

        {/* Right column: Primary Dynamic Workspace Viewport */}
        <section className="lg:col-span-8 h-full">
          {activeTab === 'play' && (
            <GameCanvas
              activeSkinId={activeSkin}
              onGameEnd={onGameEnd}
            />
          )}

          {activeTab === 'shop' && (
            <SkinsShop
              userProfile={userProfile}
              anonymousCoins={anonCoins}
              anonymousUnlockedSkins={anonUnlockedSkins}
              anonymousActiveSkin={anonActiveSkin}
              onSelectSkin={onSelectSkin}
              onBuySkin={onBuySkin}
            />
          )}

          {activeTab === 'leaderboard' && (
            <Leaderboard
              currentUserId={user ? user.uid : null}
            />
          )}
        </section>

      </main>

      {/* Retro styled page base footer */}
      <footer className="mt-auto py-5 border-t border-zinc-900 text-center relative z-10 px-4">
        <p className="text-[10px] font-mono text-zinc-600 tracking-wider">
          CYBER SNAKE GAME ARCHITECTURE DEPLOYED IN SECURE CONTAINER ENVIRONMENT • CLOUD SECURE DEPLOYMENT PROTOCOL ACTIVE
        </p>
      </footer>
    </div>
  );
}
