import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc, collection, query, orderBy, limit, getDocs, addDoc } from 'firebase/firestore';
import firebaseConfig from '@/firebase-applet-config.json';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth();
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Global user profile schema helper
export interface UserProfile {
  userId: string;
  displayName: string;
  photoURL?: string;
  coins: number;
  highScore: number;
  unlockedSkins: string[];
  activeSkin: string;
  createdAt: any; // Timestamp / FieldValue
  updatedAt: any;
}

// Leaderboard item schema helper
export interface LeaderboardEntry {
  userId: string;
  displayName: string;
  score: number;
  skinUsed: string;
  createdAt: any;
}

// Whitelist of valid skins in the shop
export interface SkinInfo {
  id: string;
  name: string;
  price: number;
  description: string;
  textColor: string;
  glowColor: string;
  bodyColor: string;
  headColor: string;
  pattern: 'solid' | 'glow' | 'gradient' | 'rainbow' | 'stealth' | 'dragon' | 'ghost';
}

export const SKINS_SHOP: SkinInfo[] = [
  {
    id: 'classic',
    name: 'Classic Green',
    price: 0,
    description: 'The legendary nostalgic green. Simple and reliable.',
    textColor: 'text-green-400',
    glowColor: 'rgba(74, 222, 128, 0.5)',
    bodyColor: 'bg-green-500Border', // wait, let's use exact bg color styling
    headColor: 'bg-green-400',
    pattern: 'solid'
  },
  {
    id: 'neon_blue',
    name: 'Cyber Neon Blue',
    price: 150,
    description: 'A brilliant sapphire neon skin that pulses in the dark.',
    textColor: 'text-cyan-400',
    glowColor: 'rgba(34, 211, 238, 0.8)',
    bodyColor: 'bg-cyan-500',
    headColor: 'bg-cyan-300',
    pattern: 'glow'
  },
  {
    id: 'sunset_orange',
    name: 'Retro Sunset',
    price: 300,
    description: 'An aggressive vermilion skin reflecting 80s arcade sunsets.',
    textColor: 'text-orange-400',
    glowColor: 'rgba(251, 146, 60, 0.7)',
    bodyColor: 'bg-gradient-to-r from-orange-600 to-amber-500',
    headColor: 'bg-orange-400',
    pattern: 'gradient'
  },
  {
    id: 'stealth_gray',
    name: 'Stealth Matte',
    price: 500,
    description: 'A hardened carbon fiber tactical look. Low profile, high focus.',
    textColor: 'text-zinc-400',
    glowColor: 'rgba(161, 161, 170, 0.3)',
    bodyColor: 'bg-zinc-700',
    headColor: 'bg-zinc-500',
    pattern: 'stealth'
  },
  {
    id: 'rainbow',
    name: 'Rainbow Disco',
    price: 800,
    description: 'Full chromatic shifting spectrum. Command attention as you grow.',
    textColor: 'text-pink-400',
    glowColor: 'rgba(244, 63, 94, 0.8)',
    bodyColor: 'bg-gradient-to-r from-red-500 via-green-500 via-blue-500 to-yellow-500 animate-pulse',
    headColor: 'bg-white',
    pattern: 'rainbow'
  },
  {
    id: 'ghost',
    name: 'Pixel Ghost',
    price: 1200,
    description: 'A semi-transparent ectoplasm style. Slip through the grids like a phantom.',
    textColor: 'text-purple-300',
    glowColor: 'rgba(192, 132, 252, 0.4)',
    bodyColor: 'bg-purple-500/50 backdrop-blur-xs',
    headColor: 'bg-purple-300/80',
    pattern: 'ghost'
  },
  {
    id: 'golden_dragon',
    name: 'Golden Dragon',
    price: 2000,
    description: 'The ultimate snake armor forged of dynamic liquid gold and fire.',
    textColor: 'text-yellow-400 font-bold',
    glowColor: 'rgba(250, 204, 21, 0.9)',
    bodyColor: 'bg-gradient-to-r from-yellow-600 via-amber-400 to-yellow-500',
    headColor: 'bg-yellow-300',
    pattern: 'dragon'
  }
];

// Helper: Signs in with Google PopUp
export async function loginWithGoogle(): Promise<string | null> {
  try {
    const response = await signInWithPopup(auth, googleProvider);
    return response.user.uid;
  } catch (error: any) {
    const errMsg = error?.message || String(error);
    if (error?.code === 'auth/popup-closed-by-user' || errMsg.includes('popup-closed-by-user')) {
      console.info('Google Sign-in popup was closed by the user.');
    } else {
      console.warn('Google Login warning:', error);
    }
    throw error;
  }
}

// Helper: Log out
export async function logout(): Promise<void> {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Sign Out Error:', error);
  }
}
