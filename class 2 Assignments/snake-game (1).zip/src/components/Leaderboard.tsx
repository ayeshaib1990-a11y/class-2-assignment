import { useEffect, useState } from 'react';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, LeaderboardEntry, SKINS_SHOP } from '../firebase';
import { Trophy, Flame, User, Award, ShieldAlert, Loader2 } from 'lucide-react';

interface LeaderboardProps {
  currentUserId: string | null;
}

export default function Leaderboard({ currentUserId }: LeaderboardProps) {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Only subscribe to the leaderboard if the user is authenticated (Firebase security rules requirement)
    if (!currentUserId) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const q = query(
      collection(db, 'leaderboard'),
      orderBy('score', 'desc'),
      limit(15) // Top 15 players
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const leaderboardData: LeaderboardEntry[] = [];
        snapshot.forEach((doc) => {
          leaderboardData.push(doc.data() as LeaderboardEntry);
        });
        setEntries(leaderboardData);
        setLoading(false);
      },
      (err) => {
        setError('Unable to fetch leaderboard.');
        setLoading(false);
        try {
          handleFirestoreError(err, OperationType.LIST, 'leaderboard');
        } catch (e) {
          // Handled
        }
      }
    );

    return () => unsubscribe();
  }, [currentUserId]);

  const getRankBadgeAndStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return {
          bg: 'bg-yellow-500/20 border-yellow-500/50 text-yellow-400',
          glow: 'shadow-[0_0_15px_rgba(234,179,8,0.3)]',
          label: '🥇'
        };
      case 2:
        return {
          bg: 'bg-slate-300/20 border-slate-300/50 text-slate-200',
          glow: 'shadow-[0_0_15px_rgba(203,213,225,0.2)]',
          label: '🥈'
        };
      case 3:
        return {
          bg: 'bg-amber-600/20 border-amber-600/50 text-amber-500',
          glow: 'shadow-[0_0_15px_rgba(217,119,6,0.2)]',
          label: '🥉'
        };
      default:
        return {
          bg: 'bg-zinc-800/40 border-zinc-700/50 text-zinc-400',
          glow: '',
          label: `#${rank}`
        };
    }
  };

  const getSkinDetails = (skinId: string) => {
    return SKINS_SHOP.find(s => s.id === skinId) || SKINS_SHOP[0];
  };

  if (!currentUserId) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center h-full min-h-[400px] bg-card-bg border-2 border-zinc-800 relative">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#0c0c0c_1px,transparent_1px),linear-gradient(to_bottom,#0c0c0c_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none opacity-40"></div>
        <div className="relative z-10 max-w-sm">
          <div className="w-16 h-16 border-2 border-accent flex items-center justify-center mx-auto mb-6 shadow-[0_0_15px_rgba(204,255,0,0.2)]">
            <span className="font-black text-2xl italic text-accent">$</span>
          </div>
          <h3 className="text-2xl font-black uppercase italic tracking-tighter mb-2">Hall of Venom</h3>
          <p className="text-zinc-400 text-xs leading-relaxed mb-6 font-mono uppercase">
            Sign in with Google to sync accomplishments, unlock live rankings, and claim a slot premium slot on the world network node.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-card-bg border-2 border-zinc-800 p-6 md:p-8 relative">
      {/* Header Container */}
      <div className="flex justify-between items-baseline border-b-2 border-accent pb-4 mb-6">
        <h2 className="text-4xl sm:text-5xl font-black uppercase italic tracking-tighter">Hall of Venom</h2>
        <div className="text-[10px] font-mono text-zinc-500 text-right uppercase">
          Live Node Sync<br />Active Status
        </div>
      </div>

      {/* Leaderboard Table */}
      <div className="flex-1 overflow-y-auto space-y-1 pr-1 max-h-[500px]">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-48 gap-3">
            <Loader2 className="w-8 h-8 text-accent animate-spin" />
            <span className="text-xs text-zinc-500 font-mono tracking-widest">LOADING CORE LEADERBOARD NODE...</span>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center h-48 text-center p-4 border border-zinc-800">
            <ShieldAlert className="w-8 h-8 text-red-500 mb-2" />
            <h4 className="text-xs font-mono font-bold uppercase text-red-400">Sync Failure</h4>
            <p className="text-xs text-zinc-500 mt-1 font-mono">{error}</p>
          </div>
        ) : entries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-center p-6 border-2 border-dashed border-zinc-850">
            <Award className="w-10 h-10 text-zinc-600 mb-2" />
            <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-[#888]">NO STAT DATA SECURED</h4>
            <p className="text-xs text-zinc-600 mt-1 font-mono uppercase">Initiate a classic run and set the very first high score node.</p>
          </div>
        ) : (
          <>
            {/* Table Header */}
            <div className="flex text-[10px] uppercase font-bold text-accent border-b border-zinc-800 pb-2 mb-3 tracking-[0.2em] font-mono">
              <div className="w-12">Rank</div>
              <div className="flex-1">Slayer</div>
              <div className="w-32 text-right">Points</div>
            </div>

            <div className="space-y-1">
              {entries.map((entry, idx) => {
                const rank = idx + 1;
                const skinDetails = getSkinDetails(entry.skinUsed);
                const isSelf = entry.userId === currentUserId;

                return (
                  <div
                    key={`${entry.userId}-${entry.createdAt?.seconds || idx}`}
                    className={`flex items-center justify-between p-3 border-b border-zinc-900 transition-colors duration-150 ${
                      isSelf
                        ? 'bg-accent text-black font-black'
                        : 'bg-[#151515]/30 hover:bg-accent hover:text-black group'
                    }`}
                  >
                    {/* User and rank */}
                    <div className="flex items-center gap-4 min-w-0">
                      <span className={`w-12 italic font-black font-mono text-xl ${isSelf ? 'text-black' : 'text-[#888] group-hover:text-black'}`}>
                        {rank.toString().padStart(2, '0')}
                      </span>
                      
                      <div className="min-w-0">
                        <p className={`text-base font-bold font-mono uppercase tracking-tighter truncate ${isSelf ? 'text-black' : 'text-white group-hover:text-black'}`}>
                          {entry.displayName || 'Anonymous Slayers'}
                          {isSelf && <span className="ml-1.5 text-[9px] font-sans font-bold bg-black text-accent px-1.5 py-0.5">YOU</span>}
                        </p>
                        <p className={`text-[10px] font-mono lowercase truncate ${isSelf ? 'text-black/80' : 'text-[#888] group-hover:text-black/80'}`}>
                          {skinDetails.name} active
                        </p>
                      </div>
                    </div>

                    {/* High Score */}
                    <div className="text-right pl-3">
                      <p className={`text-xl font-black font-mono leading-none tracking-tight ${isSelf ? 'text-black font-extrabold' : 'text-white group-hover:text-black'}`}>
                        {entry.score.toLocaleString()}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>
      
      {/* Footer statistic details */}
      <div className="mt-4 pt-4 border-t border-zinc-800 text-center uppercase">
        <p className="text-[9px] font-mono text-[#888] tracking-widest">
          SYSTEM SHIELD IMMUTABLE RECORDS • HIGH SCORES SECURED VIA SECURE DEPLOYMENT PROTOCOLS
        </p>
      </div>
    </div>
  );
}
