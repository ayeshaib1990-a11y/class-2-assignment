import { useEffect, useRef, useState, useCallback } from 'react';
import { SKINS_SHOP, SkinInfo } from '../firebase';
import { Play, RotateCcw, Volume2, VolumeX, Pause, ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Zap, Target } from 'lucide-react';

interface GameCanvasProps {
  activeSkinId: string;
  onGameEnd: (score: number, coinsEarned: number) => void;
}

interface Point {
  x: number;
  y: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  decay: number;
}

const GRID_SIZE = 20;

export default function GameCanvas({ activeSkinId, onGameEnd }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // Game states
  const [score, setScore] = useState(0);
  const [coinsEarned, setCoinsEarned] = useState(0);
  const [gameState, setGameState] = useState<'IDLE' | 'PLAYING' | 'PAUSED' | 'GAMEOVER'>('IDLE');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Snake engine refs (to avoid closure stale state in the game loop)
  const snakeRef = useRef<Point[]>([{ x: 10, y: 10 }, { x: 10, y: 11 }, { x: 10, y: 12 }]);
  const directionRef = useRef<Point>({ x: 0, y: -1 });
  const nextDirectionRef = useRef<Point>({ x: 0, y: -1 });
  const foodRef = useRef<Point>({ x: 5, y: 5 });
  const goldenFoodRef = useRef<Point | null>(null);
  const goldenFoodTimerRef = useRef<number>(0);
  const particlesRef = useRef<Particle[]>([]);
  const loopTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const speedRef = useRef<number>(140); // ms per tick

  const skinDetails = SKINS_SHOP.find(s => s.id === activeSkinId) || SKINS_SHOP[0];

  // Synthesis engine for clean procedural audio
  const playSynthesizedSound = (type: 'eat' | 'golden' | 'gameover' | 'tick') => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'eat') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.12);
        osc.start();
        osc.stop(ctx.currentTime + 0.12);
      } else if (type === 'golden') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.08);
        osc.frequency.exponentialRampToValueAtTime(1318.51, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.25);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      } else if (type === 'gameover') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(180, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(50, ctx.currentTime + 0.4);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.4);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
      } else if (type === 'tick') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(150, ctx.currentTime);
        gain.gain.setValueAtTime(0.02, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.04);
        osc.start();
        osc.stop(ctx.currentTime + 0.04);
      }
    } catch (e) {
      console.warn('Audio synthesis failed to start:', e);
    }
  };

  // Generate safe coordinates for food
  const generateNewFoodCoords = useCallback((): Point => {
    let attempts = 0;
    while (attempts < 200) {
      const rx = Math.floor(Math.random() * GRID_SIZE);
      const ry = Math.floor(Math.random() * GRID_SIZE);
      // Check if inside snake body
      const collides = snakeRef.current.some(segment => segment.x === rx && segment.y === ry);
      if (!collides) {
        return { x: rx, y: ry };
      }
      attempts++;
    }
    return { x: 3, y: 3 };
  }, []);

  // Spawn explosion particles
  const spawnParticles = (x: number, y: number, color: string, count: number = 10) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const tileWidth = canvas.width / GRID_SIZE;
    const tileHeight = canvas.height / GRID_SIZE;
    
    // Pixel coordinates
    const px = x * tileWidth + tileWidth / 2;
    const py = y * tileHeight + tileHeight / 2;

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1 + Math.random() * 4;
      particlesRef.current.push({
        x: px,
        y: py,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: color,
        size: 1.5 + Math.random() * 3,
        alpha: 1.0,
        decay: 0.03 + Math.random() * 0.04
      });
    }
  };

  // Handle changing cell directions
  const handleDirectionChange = (dx: number, dy: number) => {
    const curDx = directionRef.current.x;
    const curDy = directionRef.current.y;
    // Prevent self-reversal
    if (dx !== 0 && curDx !== 0) return;
    if (dy !== 0 && curDy !== 0) return;

    nextDirectionRef.current = { x: dx, y: dy };
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['Space', ' ', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault(); // Pause scrolled jumps
      }

      if (gameState !== 'PLAYING') {
        if (gameState === 'IDLE' && (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W')) {
          setGameState('PLAYING');
        } else {
          return;
        }
      }

      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          handleDirectionChange(0, -1);
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          handleDirectionChange(0, 1);
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          handleDirectionChange(-1, 0);
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          handleDirectionChange(1, 0);
          break;
        case 'p':
        case 'P':
        case ' ':
          togglePause();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState]);

  // Main tick updater
  const runGameTick = useCallback(() => {
    if (gameState !== 'PLAYING') return;

    // Flush direction update
    directionRef.current = nextDirectionRef.current;
    const dir = directionRef.current;
    
    const head = snakeRef.current[0];
    const newHead = {
      x: head.x + dir.x,
      y: head.y + dir.y
    };

    // Edge check or border self-collisions
    if (
      newHead.x < 0 || newHead.x >= GRID_SIZE ||
      newHead.y < 0 || newHead.y >= GRID_SIZE ||
      snakeRef.current.some(segment => segment.x === newHead.x && segment.y === newHead.y)
    ) {
      // Game Over
      playSynthesizedSound('gameover');
      setGameState('GAMEOVER');
      onGameEnd(score, coinsEarned);
      return;
    }

    // Attach head
    const newSnake = [newHead, ...snakeRef.current];

    // Determine if food is eaten
    let foodEaten = false;
    let goldenEaten = false;

    if (newHead.x === foodRef.current.x && newHead.y === foodRef.current.y) {
      foodEaten = true;
      setScore(prev => prev + 1);
      setCoinsEarned(prev => prev + 5);
      spawnParticles(newHead.x, newHead.y, '#22c55e', 14);
      playSynthesizedSound('eat');
      foodRef.current = generateNewFoodCoords();

      // Spawn golden food coordinates (15% chance if not already active)
      if (!goldenFoodRef.current && Math.random() < 0.15) {
        goldenFoodRef.current = generateNewFoodCoords();
        goldenFoodTimerRef.current = 28; // Ticks before disappearing
      }
    } else if (goldenFoodRef.current && newHead.x === goldenFoodRef.current.x && newHead.y === goldenFoodRef.current.y) {
      goldenEaten = true;
      setScore(prev => prev + 3);
      setCoinsEarned(prev => prev + 25);
      spawnParticles(newHead.x, newHead.y, '#eab308', 25);
      playSynthesizedSound('golden');
      goldenFoodRef.current = null;
    }

    if (!foodEaten && !goldenEaten) {
      // Pop tail to preserve size
      newSnake.pop();
    }

    // Update golden timer
    if (goldenFoodRef.current) {
      goldenFoodTimerRef.current -= 1;
      if (goldenFoodTimerRef.current <= 0) {
        goldenFoodRef.current = null;
      }
    }

    snakeRef.current = newSnake;

    // Adjust speed dynamic according to score (faster every 5 scores)
    const baseSpeed = 140;
    const speedReduction = Math.min(80, Math.floor(score / 5) * 6);
    speedRef.current = baseSpeed - speedReduction;

    // Re-schedule loop
    loopTimeoutRef.current = setTimeout(runGameTick, speedRef.current);
  }, [gameState, score, coinsEarned, generateNewFoodCoords, onGameEnd]);

  // Handle running loops
  useEffect(() => {
    if (gameState === 'PLAYING') {
      loopTimeoutRef.current = setTimeout(runGameTick, speedRef.current);
    }
    return () => {
      if (loopTimeoutRef.current) clearTimeout(loopTimeoutRef.current);
    };
  }, [gameState, runGameTick]);

  // Render routine
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const tileW = canvas.width / GRID_SIZE;
      const tileH = canvas.height / GRID_SIZE;

      // 1. Draw glowing grid lines for that cyberpunk sector vibe
      ctx.strokeStyle = 'rgba(63, 63, 70, 0.2)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= GRID_SIZE; i++) {
        // Vertical lines
        ctx.beginPath();
        ctx.moveTo(i * tileW, 0);
        ctx.lineTo(i * tileW, canvas.height);
        ctx.stroke();

        // Horizontal lines
        ctx.beginPath();
        ctx.moveTo(0, i * tileH);
        ctx.lineTo(canvas.width, i * tileH);
        ctx.stroke();
      }

      // 2. Draw standard food (Glowing Neon Red Orb)
      const foodX = foodRef.current.x * tileW + tileW / 2;
      const foodY = foodRef.current.y * tileH + tileH / 2;
      const foodRadius = tileW / 2.3;

      ctx.save();
      ctx.beginPath();
      ctx.arc(foodX, foodY, foodRadius, 0, Math.PI * 2);
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#f43f5e';
      ctx.fillStyle = '#f43f5e';
      ctx.fill();
      // Shimmer accent
      ctx.beginPath();
      ctx.arc(foodX - foodRadius / 3, foodY - foodRadius / 3, foodRadius / 4, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fill();
      ctx.restore();

      // 3. Draw golden food if existing (Super Nova Shimmering Gold Orb)
      if (goldenFoodRef.current) {
        const goldX = goldenFoodRef.current.x * tileW + tileW / 2;
        const goldY = goldenFoodRef.current.y * tileH + tileH / 2;
        const goldRadius = tileW / 2;

        ctx.save();
        ctx.beginPath();
        ctx.arc(goldX, goldY, goldRadius, 0, Math.PI * 2);
        // Pulse glow effect
        const pulse = 10 + Math.sin(Date.now() / 80) * 4;
        ctx.shadowBlur = pulse;
        ctx.shadowColor = '#fbbf24';
        ctx.fillStyle = '#fbbf24';
        ctx.fill();
        // Core glow
        ctx.beginPath();
        ctx.arc(goldX, goldY, goldRadius * 0.6, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        ctx.restore();
      }

      // 4. Draw Snake
      const snake = snakeRef.current;
      snake.forEach((segment, index) => {
        const sx = segment.x * tileW;
        const sy = segment.y * tileH;
        const isHead = index === 0;

        ctx.save();
        ctx.beginPath();

        // Glowing parameters based on the active skin Info
        if (skinDetails.pattern === 'glow') {
          ctx.shadowBlur = 12;
          ctx.shadowColor = skinDetails.glowColor;
        } else if (skinDetails.pattern === 'dragon') {
          ctx.shadowBlur = 15;
          ctx.shadowColor = 'rgba(250, 204, 21, 0.8)';
        } else if (skinDetails.pattern === 'rainbow') {
          ctx.shadowBlur = 10;
          ctx.shadowColor = 'rgba(244, 63, 94, 0.6)';
        }

        // Draw segment shape (beveled rectangles or round connectors)
        ctx.roundRect(sx + 1, sy + 1, tileW - 2, tileH - 2, isHead ? 6 : 4);

        // Fill style based on index/gradient/rainbow pattern
        if (skinDetails.pattern === 'rainbow') {
          const hue = (index * 25 + Date.now() / 15) % 360;
          ctx.fillStyle = `hsl(${hue}, 85%, 60%)`;
        } else if (skinDetails.pattern === 'gradient') {
          const grad = ctx.createLinearGradient(sx, sy, sx + tileW, sy + tileH);
          grad.addColorStop(0, '#ea580c');
          grad.addColorStop(1, '#f59e0b');
          ctx.fillStyle = grad;
        } else if (skinDetails.pattern === 'dragon') {
          // Fire effect
          const pulseGold = (Math.sin(Date.now() / 100 + index) * 20) + 50;
          ctx.fillStyle = `hsl(45, 95%, ${pulseGold}%)`;
        } else {
          ctx.fillStyle = isHead ? (skinDetails.id === 'classic' ? '#22c55e' : '#22d3ee') : (skinDetails.id === 'classic' ? '#15803d' : '#0891b2');
          if (skinDetails.id === 'stealth_gray') {
            ctx.fillStyle = isHead ? '#71717a' : '#3f3f46';
          }
          if (skinDetails.id === 'ghost') {
            ctx.fillStyle = isHead ? 'rgba(168, 85, 247, 0.7)' : 'rgba(168, 85, 247, 0.35)';
          }
        }

        ctx.fill();

        // Eyes on the head
        if (isHead) {
          ctx.fillStyle = '#ffffff';
          const eyeSize = tileW / 6;
          const dir = directionRef.current;

          let leftEye = { x: 0, y: 0 };
          let rightEye = { x: 0, y: 0 };

          // Position eyes depending on moving direction
          if (dir.x !== 0) { // Horizontal movement
            leftEye = { x: sx + (dir.x > 0 ? tileW - 6 : 4), y: sy + 4 };
            rightEye = { x: sx + (dir.x > 0 ? tileW - 6 : 4), y: sy + tileH - 6 };
          } else { // Vertical movement
            leftEye = { x: sx + 4, y: sy + (dir.y > 0 ? tileH - 6 : 4) };
            rightEye = { x: sx + tileW - 6, y: sy + (dir.y > 0 ? tileH - 6 : 4) };
          }

          // Pupil beads
          ctx.beginPath();
          ctx.arc(leftEye.x, leftEye.y, eyeSize, 0, Math.PI * 2);
          ctx.arc(rightEye.x, rightEye.y, eyeSize, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#000000';
          ctx.beginPath();
          ctx.arc(leftEye.x, leftEye.y, eyeSize / 2, 0, Math.PI * 2);
          ctx.arc(rightEye.x, rightEye.y, eyeSize / 2, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      });

      // 5. Draw Particle Bursts
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= p.decay;

        if (p.alpha <= 0) {
          particles.splice(i, 1);
        } else {
          ctx.save();
          ctx.globalAlpha = p.alpha;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.shadowBlur = 6;
          ctx.shadowColor = p.color;
          ctx.fill();
          ctx.restore();
        }
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animationId);
  }, [skinDetails]);

  // Start the actual session
  const startGame = () => {
    snakeRef.current = [{ x: 10, y: 10 }, { x: 10, y: 11 }, { x: 10, y: 12 }];
    directionRef.current = { x: 0, y: -1 };
    nextDirectionRef.current = { x: 0, y: -1 };
    foodRef.current = generateNewFoodCoords();
    goldenFoodRef.current = null;
    particlesRef.current = [];
    setScore(0);
    setCoinsEarned(0);
    setGameState('PLAYING');
    playSynthesizedSound('tick');
  };

  const togglePause = () => {
    if (gameState === 'PLAYING') {
      setGameState('PAUSED');
    } else if (gameState === 'PAUSED') {
      setGameState('PLAYING');
    }
  };

  return (
    <div className="flex flex-col items-center bg-card-bg border-2 border-zinc-800 p-6 md:p-8 relative h-full rounded-none">
      {/* Dynamic Background Mesh Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0c0c0c_1px,transparent_1px),linear-gradient(to_bottom,#0c0c0c_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none opacity-40"></div>

      {/* Control Widgets */}
      <div className="w-full flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center gap-6">
          <div>
            <span className="text-[10px] text-[#888] uppercase tracking-widest font-mono font-black">Score Nodes</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-2xl font-black text-white font-mono leading-none">{score}</span>
              <span className="text-xs font-mono text-zinc-500">PTS</span>
            </div>
          </div>

          <div>
            <span className="text-[10px] text-[#888] uppercase tracking-widest font-mono font-black">Sparks accrued</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-2xl font-black text-accent font-mono leading-none">+{coinsEarned}</span>
              <span className="text-xs font-mono text-accent">CR</span>
            </div>
          </div>
        </div>

        {/* Audio Muter */}
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="p-3 bg-zinc-950 border-2 border-zinc-800 text-[#888] hover:text-accent hover:border-accent transition-colors cursor-pointer rounded-none"
          title={soundEnabled ? 'Mute' : 'Unmute'}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      </div>

      {/* Main Screen Container */}
      <div className="relative w-full aspect-square max-w-[360px] md:max-w-[400px] bg-zinc-950 rounded-none overflow-hidden border-2 border-zinc-800 shadow-none flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={400}
          height={400}
          className="w-full h-full block"
        />

        {/* Dynamic State Overlays */}
        {gameState === 'IDLE' && (
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="w-16 h-16 border-2 border-accent flex items-center justify-center text-accent mb-6 animate-bounce">
              <Play className="w-8 h-8 translate-x-0.5 text-accent" />
            </div>
            <h3 className="text-4xl font-black text-white tracking-tighter uppercase italic leading-none mb-2">
              NEO<span className="text-accent">SNAKE</span>
            </h3>
            <p className="text-[#888] text-xs max-w-xs leading-relaxed mb-6 font-mono uppercase">
              Navigate the vector coordinate grid, acquire glowing green spark cells, and upgrade active power skin armors.
            </p>
            <button
              onClick={startGame}
              className="px-8 py-3 bg-accent text-black font-black uppercase text-xs tracking-widest shadow-[4px_4px_0px_0px_#FFFFFF] cursor-pointer hover:bg-white transition-colors duration-150"
            >
              INITIALIZE MODULE
            </button>
          </div>
        )}

        {gameState === 'PAUSED' && (
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xs flex flex-col items-center justify-center z-20">
            <Pause className="w-12 h-12 text-accent mb-4 animate-pulse" />
            <span className="text-2xl font-black font-mono tracking-widest uppercase italic text-white mb-2">Sector Paused</span>
            <p className="text-[#888] text-xs font-mono uppercase mb-6">Coordinate update pending resume action</p>
            <button
              onClick={togglePause}
              className="px-8 py-3 bg-white text-black font-black uppercase text-xs tracking-widest shadow-[4px_4px_0px_0px_#CCFF00] cursor-pointer"
            >
              RESUME SYSTEM
            </button>
          </div>
        )}

        {gameState === 'GAMEOVER' && (
          <div className="absolute inset-0 bg-black/95 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center animate-fade-in z-20">
            <div className="w-16 h-16 border-2 border-red-500 flex items-center justify-center text-red-500 mb-6">
              <RotateCcw className="w-7 h-7" />
            </div>
            <h3 className="text-3xl font-black text-red-500 uppercase italic tracking-tighter leading-none mb-2">SYSTEM TERMINATED</h3>
            <p className="text-zinc-300 text-sm font-mono uppercase tracking-wider mb-2">
              GRID SCORE SECURED: <span className="font-black text-white text-lg">{score}</span>
            </p>
            <p className="text-[#888] text-xs max-w-xs leading-relaxed mb-6 font-mono uppercase">
              Vault balance increased by <span className="text-accent font-bold">{coinsEarned} CR</span>. Boot skin shop upgrades.
            </p>
            <div className="flex gap-4">
              <button
                onClick={startGame}
                className="px-8 py-3 bg-accent text-black font-black uppercase text-xs tracking-widest shadow-[4px_4px_0px_0px_#FFFFFF] cursor-pointer hover:bg-white transition-colors duration-150"
              >
                RE-BOOT GAME
              </button>
            </div>
          </div>
        )}

        {/* Golden Food Active Banner Alert */}
        {goldenFoodRef.current && gameState === 'PLAYING' && (
          <div className="absolute top-3 left-3 bg-accent text-black font-black font-mono text-[9px] uppercase px-3 py-1 border border-accent shadow-lg flex items-center gap-1.5 animate-pulse">
            <Zap className="w-3 h-3" /> GOLD SIGNAL: Grid cell active ({goldenFoodTimerRef.current})
          </div>
        )}
      </div>

      {/* D-Pad controls for mobile & ease of touch layout */}
      <div className="mt-6 w-full max-w-[200px] flex flex-col items-center gap-2 relative z-10 select-none">
        <button
          onTouchStart={() => handleDirectionChange(0, -1)}
          onMouseDown={() => handleDirectionChange(0, -1)}
          className="w-12 h-12 bg-zinc-950 hover:bg-zinc-900 border-2 border-zinc-800 hover:border-accent text-[#888] hover:text-white active:bg-accent active:text-black flex items-center justify-center cursor-pointer transition-colors rounded-none"
          title="Move Up"
        >
          <ChevronUp className="w-6 h-6" />
        </button>

        <div className="w-full flex justify-between">
          <button
            onTouchStart={() => handleDirectionChange(-1, 0)}
            onMouseDown={() => handleDirectionChange(-1, 0)}
            className="w-12 h-12 bg-zinc-950 hover:bg-zinc-900 border-2 border-zinc-800 hover:border-accent text-[#888] hover:text-white active:bg-accent active:text-black flex items-center justify-center cursor-pointer transition-colors rounded-none"
            title="Move Left"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <button
            onClick={togglePause}
            disabled={gameState !== 'PLAYING' && gameState !== 'PAUSED'}
            className="w-12 h-12 bg-zinc-950 border-2 border-zinc-800 text-zinc-500 flex items-center justify-center text-xs font-black font-mono uppercase tracking-tighter cursor-pointer disabled:opacity-40 rounded-none"
            title="Pause Game"
          >
            {gameState === 'PAUSED' ? 'GO' : '||'}
          </button>

          <button
            onTouchStart={() => handleDirectionChange(1, 0)}
            onMouseDown={() => handleDirectionChange(1, 0)}
            className="w-12 h-12 bg-zinc-950 hover:bg-zinc-900 border-2 border-zinc-800 hover:border-accent text-[#888] hover:text-white active:bg-accent active:text-black flex items-center justify-center cursor-pointer transition-colors rounded-none"
            title="Move Right"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        <button
          onTouchStart={() => handleDirectionChange(0, 1)}
          onMouseDown={() => handleDirectionChange(0, 1)}
          className="w-12 h-12 bg-zinc-950 hover:bg-zinc-900 border-2 border-zinc-800 hover:border-accent text-[#888] hover:text-white active:bg-accent active:text-black flex items-center justify-center cursor-pointer transition-colors rounded-none"
          title="Move Down"
        >
          <ChevronDown className="w-6 h-6" />
        </button>
      </div>

      <div className="mt-4 text-[9px] text-zinc-500 font-mono text-center uppercase tracking-wider">
        KEYBOARD NAVIGATION • ARROWS / WASD TO PILOT • SPACE KEY PAUSES SECTOR
      </div>
    </div>
  );
}
