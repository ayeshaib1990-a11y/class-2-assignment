import { useState } from 'react';
import { SKINS_SHOP, SkinInfo, UserProfile } from '../firebase';
import { Sparkles, Coins, Check, ShoppingBag, Eye, Lock } from 'lucide-react';

interface SkinsShopProps {
  userProfile: UserProfile | null;
  anonymousCoins: number;
  anonymousUnlockedSkins: string[];
  anonymousActiveSkin: string;
  onSelectSkin: (skinId: string) => Promise<void>;
  onBuySkin: (skinId: string, price: number) => Promise<void>;
}

export default function SkinsShop({
  userProfile,
  anonymousCoins,
  anonymousUnlockedSkins,
  anonymousActiveSkin,
  onSelectSkin,
  onBuySkin,
}: SkinsShopProps) {
  const [selectedPreview, setSelectedPreview] = useState<SkinInfo>(SKINS_SHOP[0]);
  const [buyingId, setBuyingId] = useState<string | null>(null);

  // Derive unlocked/active properties depending on auth status
  const coins = userProfile ? userProfile.coins : anonymousCoins;
  const unlockedSkins = userProfile ? userProfile.unlockedSkins : anonymousUnlockedSkins;
  const activeSkin = userProfile ? userProfile.activeSkin : anonymousActiveSkin;

  const handleBuy = async (skin: SkinInfo) => {
    if (coins < skin.price) return;
    setBuyingId(skin.id);
    try {
      await onBuySkin(skin.id, skin.price);
    } catch (e) {
      console.error(e);
    } finally {
      setBuyingId(null);
    }
  };

  const renderSkinPreview = (skin: SkinInfo) => {
    // Generate a mini chain of dots representing snake segments
    const dotClasses = (idx: number) => {
      let extra = '';
      if (skin.pattern === 'glow') extra = 'shadow-[0_0_8px_rgba(34,211,238,0.8)]';
      if (skin.pattern === 'rainbow') {
        const rainbowColors = ['bg-rose-500', 'bg-amber-400', 'bg-emerald-400', 'bg-sky-400'];
        return `${rainbowColors[idx % 4]} w-5 h-5 rounded-full border border-white/15`;
      }
      return `${idx === 0 ? skin.headColor : skin.bodyColor} w-5 h-5 rounded-full border border-black/10 ${extra}`;
    };

    return (
      <div className="flex gap-1.5 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80 w-fit justify-center mx-auto shadow-inner">
        <div className={`${dotClasses(0)} relative flex items-center justify-center`}>
          {/* Snake eyes */}
          <span className="absolute w-1 h-1 bg-black rounded-full top-1 left-1"></span>
          <span className="absolute w-1 h-1 bg-black rounded-full bottom-1 left-1"></span>
        </div>
        <div className={dotClasses(1)}></div>
        <div className={dotClasses(2)}></div>
        <div className={dotClasses(3)}></div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-card-bg border-2 border-zinc-800 p-6 md:p-8 relative">
      
      {/* Shop Header */}
      <div className="flex justify-between items-baseline border-b-2 border-accent pb-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 border-2 border-accent flex items-center justify-center">
            <span className="font-extrabold text-lg italic text-accent">$</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-black uppercase italic tracking-tighter">SKIN VAULT</h2>
        </div>
        
        {/* Wallet Display */}
        <div className="text-right">
          <p className="text-[10px] uppercase tracking-widest text-[#888] font-bold">Your Balance</p>
          <p className="text-xl sm:text-2xl font-mono font-black text-accent">{coins} CR</p>
        </div>
      </div>

      {/* Grid container */}
      <div className="flex-1 overflow-y-auto space-y-6 max-h-[500px] pr-1">
        
        {/* High Art Selected Preview Panel */}
        <div className="p-6 bg-zinc-950 border-2 border-zinc-800 relative text-center">
          <div className="absolute top-2 right-2 text-[9px] border border-accent text-accent font-mono px-2 py-0.5 uppercase tracking-wider">
            Selected Design preview
          </div>
          <div className="mb-4">
            {renderSkinPreview(selectedPreview)}
          </div>
          <h3 className={`text-xl font-black tracking-tight mb-1 uppercase italic ${selectedPreview.textColor}`}>
            {selectedPreview.name}
          </h3>
          <p className="text-zinc-400 text-xs max-w-sm mx-auto leading-relaxed font-mono uppercase">
            {selectedPreview.description}
          </p>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {SKINS_SHOP.map((skin) => {
            const isUnlocked = unlockedSkins.includes(skin.id);
            const isActive = activeSkin === skin.id;
            const canAfford = coins >= skin.price;
            const isPreviewed = selectedPreview.id === skin.id;

            return (
              <div
                key={skin.id}
                onClick={() => setSelectedPreview(skin)}
                className={`p-4 bg-[#151515] border transition-all duration-150 cursor-pointer flex flex-col justify-between rounded-none ${
                  isPreviewed
                    ? 'border-accent shadow-[0_0_15px_rgba(204,255,0,0.15)]'
                    : 'border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div>
                  <div className="w-full aspect-[4/1.5] bg-zinc-950 border border-zinc-900 flex items-center justify-center mb-3 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-accent/5 to-transparent"></div>
                    <div className="text-center scale-90">
                      {renderSkinPreview(skin)}
                    </div>
                  </div>

                  <div className="flex items-baseline justify-between mb-1">
                    <h4 className={`font-black uppercase tracking-tight text-sm ${skin.textColor}`}>{skin.name}</h4>
                    <span className="text-[9px] font-mono text-zinc-500 uppercase">{skin.pattern} pattern</span>
                  </div>
                  <p className="text-[#888] text-xs font-mono leading-relaxed mb-4 uppercase">
                    {skin.description}
                  </p>
                </div>

                <div className="mt-auto pt-2 border-t border-zinc-900">
                  {isActive ? (
                    <button
                      type="button"
                      disabled
                      className="mt-1 w-full py-2 border-2 border-accent text-accent font-black uppercase text-xs tracking-wider"
                    >
                      Equipped
                    </button>
                  ) : isUnlocked ? (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectSkin(skin.id);
                      }}
                      className="mt-1 w-full py-2 bg-white text-black font-black uppercase text-xs tracking-wider hover:bg-accent hover:text-black transition-colors"
                    >
                      Equip Skin
                    </button>
                  ) : canAfford ? (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleBuy(skin);
                      }}
                      className="mt-1 w-full py-2 bg-accent text-black font-black uppercase text-xs tracking-wider hover:bg-accent-dark transition-colors"
                    >
                      {buyingId === skin.id ? 'BUYING...' : `UNLOCK: ${skin.price} CR`}
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled
                      className="mt-1 w-full py-2 bg-zinc-900 text-zinc-600 font-bold uppercase text-xs tracking-wider cursor-not-allowed border border-zinc-800"
                    >
                      LOCKED: {skin.price} CR
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
}
